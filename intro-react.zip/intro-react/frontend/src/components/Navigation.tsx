import React from "react";

export default function Navigation() {
    return (
      <nav>
        <a href="/" target="">
          Hjem
        </a>
      </nav>
    );
  }